class Settings:
    def __init__(self, pdf_dir=None, json_dir=None, out_dir=None):
        self.pdf_dir = pdf_dir
        self.json_dir = json_dir
        self.out_dir = out_dir